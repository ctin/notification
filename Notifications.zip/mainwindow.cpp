#include "Result/Result.h"

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QToolTip>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    NotificationParams params;
    params.title = "pushButton 1";
    params.message = Result(Result::RESULT_SUCCESS, "notification on button 1");
    params.callback = [this](){
        ui->label->setText("details for button 1 clicked" );
    };
    notificationLayout.AddNotificationWidget(this, params);
}

void MainWindow::on_pushButton_2_clicked()
{
    NotificationParams params;
    params.title = "pushButton 2";
    params.message = Result(Result::RESULT_ERROR, "notification on button 2");
    params.callback = [this](){
        ui->label->setText("details for button 2 clicked" );
    };
    notificationLayout.AddNotificationWidget(this, params);
}
